r = 10
h = 50
pi = 3.14 

V = r * r * pi * h

print("Zapremina valjka je:", V)